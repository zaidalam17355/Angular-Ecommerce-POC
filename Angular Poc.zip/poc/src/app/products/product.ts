export interface Product {
    productId:string;
    categoryId:number;
    productName:string;
    descriptions:string;
    rating:string;
    productImg:string;
    isAvailable:boolean;
    color:string;
    review:number;
}
